-- query22
select i_product_name ,i_brand ,i_class ,i_category ,
        avg(inv_quantity_on_hand) qoh 
from inventory ,date_dim ,item ,warehouse 
where inv_date_sk=d_date_sk and inv_item_sk=i_item_sk and inv_warehouse_sk = 
        w_warehouse_sk and d_year=1998 
group by rollup(i_product_name ,i_brand ,i_class ,i_category) 
order by qoh, i_product_name, i_brand, i_class, i_category 
fetch first 100 rows only


;